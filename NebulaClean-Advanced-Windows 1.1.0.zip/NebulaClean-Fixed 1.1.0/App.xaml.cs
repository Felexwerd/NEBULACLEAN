using System.Windows;

namespace NebulaClean;

public partial class App : Application { }

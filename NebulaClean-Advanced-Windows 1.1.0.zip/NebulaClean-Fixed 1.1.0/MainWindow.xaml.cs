using NebulaClean.Models;
using NebulaClean.Services;
using System.IO;
using System.Diagnostics;
using Microsoft.VisualBasic.FileIO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NebulaClean;

public partial class MainWindow : Window
{
    private readonly CleanupService _cleanup = new();
    private readonly List<CleanupCategory> _categories;
    private bool _busy;

    public MainWindow()
    {
        InitializeComponent();
        _categories = _cleanup.CreateCategories().ToList();
        CategoryList.ItemsSource = _categories;
        RefreshDiskInfo();
        UpdateCategoryTotals();
    }

    private void RefreshDiskInfo()
    {
        try
        {
            string systemRoot = Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) ?? "C:\\";
            var drive = new DriveInfo(systemRoot);
            if (!drive.IsReady) return;
            long total = drive.TotalSize;
            long free = drive.AvailableFreeSpace;
            double pct = total > 0 ? free * 100d / total : 0;
            DiskFreePercent.Text = $"{pct:0}%";
            DiskFreeText.Text = CleanupCategory.FormatBytes(free);
            DiskTotalText.Text = $"Общий объём: {CleanupCategory.FormatBytes(total)}";
            DiskUsageBar.Value = 100 - pct;
            AnalyzerDiskSummary.Text = $"{CleanupCategory.FormatBytes(free)} свободно из {CleanupCategory.FormatBytes(total)}";
            AnalyzerUsageBar.Value = 100 - pct;
        }
        catch (Exception ex)
        {
            DiskFreePercent.Text = "—";
            DiskFreeText.Text = "Недоступно";
            DiskTotalText.Text = "Не удалось прочитать информацию о диске";
            AnalyzerDiskSummary.Text = $"Не удалось прочитать информацию о диске: {ex.Message}";
        }
    }

    private void ShowPage(string page, string eyebrow, string title, string subtitle)
    {
        DashboardPage.Visibility = page == "dashboard" ? Visibility.Visible : Visibility.Collapsed;
        CleanerPage.Visibility = page == "cleaner" ? Visibility.Visible : Visibility.Collapsed;
        AnalyzerPage.Visibility = page == "analyzer" ? Visibility.Visible : Visibility.Collapsed;
        HistoryPage.Visibility = page == "history" ? Visibility.Visible : Visibility.Collapsed;
        SettingsPage.Visibility = page == "settings" ? Visibility.Visible : Visibility.Collapsed;
        PageEyebrow.Text = eyebrow;
        PageTitle.Text = title;
        PageSubtitle.Text = subtitle;
        var active = new SolidColorBrush(Color.FromRgb(39, 33, 63));
        NavDashboard.Background = page == "dashboard" ? active : Brushes.Transparent;
        NavCleaner.Background = page == "cleaner" ? active : Brushes.Transparent;
        NavAnalyzer.Background = page == "analyzer" ? active : Brushes.Transparent;
        NavHistory.Background = page == "history" ? active : Brushes.Transparent;
    }

    private void NavDashboard_Click(object sender, RoutedEventArgs e) => ShowPage("dashboard", "ОБЗОР СИСТЕМЫ", "Всё под контролем.", "Проверим, что занимает место на вашем компьютере.");
    private void NavCleaner_Click(object sender, RoutedEventArgs e) => ShowPage("cleaner", "БЕЗОПАСНАЯ ОЧИСТКА", "Освободите место.", "Выберите категории и проверьте результат до удаления.");
    private void NavAnalyzer_Click(object sender, RoutedEventArgs e) => ShowPage("analyzer", "ХРАНИЛИЩЕ", "Куда уходит место?", "Информация о системном диске.");
    private void NavHistory_Click(object sender, RoutedEventArgs e) => ShowPage("history", "ЖУРНАЛ", "Ваша история.", "Результаты последней операции.");
    private void Settings_Click(object sender, RoutedEventArgs e) => ShowPage("settings", "ПАРАМЕТРЫ", "Настройки.", "Контроль над поведением приложения.");

    private async void Scan_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        ShowPage("cleaner", "БЕЗОПАСНАЯ ОЧИСТКА", "Освободите место.", "Выберите категории и проверьте результат до удаления.");
        SetBusy(true, "Сканирование выбранных категорий…");
        try
        {
            await _cleanup.ScanAsync(_categories);
            CategoryList.Items.Refresh();
            UpdateCategoryTotals();
            StatusText.Text = "Сканирование завершено. Файлы не удалялись.";
        }
        catch (OperationCanceledException) { StatusText.Text = "Сканирование отменено."; }
        catch (Exception ex) { MessageBox.Show($"Не удалось завершить сканирование.\n\n{ex.Message}", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Warning); }
        finally { SetBusy(false, StatusText.Text); }
    }

    private async void Clean_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        var selected = _categories.Where(c => c.IsSelected).ToList();
        if (selected.Count == 0)
        {
            MessageBox.Show("Выберите хотя бы одну категорию.", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        long estimate = selected.Sum(c => c.SizeBytes);
        string message = "Будут удалены файлы из выбранных временных папок и кэшей, включая вложенные папки. Личные документы, папки загрузок и системные файлы Windows не входят в очистку.\n\n"
            + string.Join("\n", selected.Select(c => $"• {c.Name} — {c.SizeText}"))
            + $"\n\nОценка объёма: {CleanupCategory.FormatBytes(estimate)}\n\nПродолжить? Занятые и недоступные файлы будут пропущены.";
        if (MessageBox.Show(message, "Подтверждение очистки", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No) != MessageBoxResult.Yes)
            return;

        SetBusy(true, "Удаление выбранных файлов…");
        try
        {
            var result = await _cleanup.CleanAsync(selected);
            HistoryText.Text = $"{DateTime.Now:dd.MM.yyyy HH:mm}\nОсвобождено: {CleanupCategory.FormatBytes(result.FreedBytes)}\nУдалено файлов: {result.DeletedFiles:N0}\nПропущено: {result.SkippedFiles:N0}";
            MessageBox.Show($"Очистка завершена.\n\nОсвобождено: {CleanupCategory.FormatBytes(result.FreedBytes)}\nУдалено файлов: {result.DeletedFiles:N0}\nПропущено: {result.SkippedFiles:N0}", "NEBULA CLEAN — готово", MessageBoxButton.OK, MessageBoxImage.Information);
            await _cleanup.ScanAsync(_categories);
            CategoryList.Items.Refresh();
            RefreshDiskInfo();
            UpdateCategoryTotals();
            StatusText.Text = "Очистка завершена.";
        }
        catch (Exception ex) { MessageBox.Show($"Очистка завершилась с ошибкой.\n\n{ex.Message}", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Warning); }
        finally { SetBusy(false, StatusText.Text); }
    }

    private async void LargeFilesScan_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        long threshold = 500L * 1024 * 1024;
        if (LargeFilesThreshold.SelectedItem is ComboBoxItem item && long.TryParse(item.Tag?.ToString(), out long parsed)) threshold = parsed;
        SetBusy(true, "Поиск больших файлов на диске C:… Это может занять несколько минут.");
        LargeFilesSummary.Text = "Идёт полный обход доступных папок…";
        LargeFilesGrid.ItemsSource = null;
        var progress = new Progress<string>(message => LargeFilesSummary.Text = message);
        try
        {
            string root = Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) ?? "C:\\";
            var files = await _cleanup.FindLargeFilesAsync(root, threshold, progress: progress);
            LargeFilesGrid.ItemsSource = files;
            LargeFilesSummary.Text = $"Найдено файлов: {files.Count:N0} · показаны крупнейшие доступные файлы";
            StatusText.Text = "Анализ больших файлов завершён.";
        }
        catch (Exception ex) { MessageBox.Show($"Не удалось завершить анализ.\n\n{ex.Message}", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Warning); }
        finally { SetBusy(false, StatusText.Text); }
    }

    private void OpenLargeFileLocation_Click(object sender, RoutedEventArgs e)
    {
        if (LargeFilesGrid.SelectedItem is not LargeFileItem file) { MessageBox.Show("Сначала выберите файл в списке.", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        try { Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{file.Path}\"") { UseShellExecute = true }); }
        catch (Exception ex) { MessageBox.Show($"Не удалось открыть расположение: {ex.Message}", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void DeleteLargeFile_Click(object sender, RoutedEventArgs e)
    {
        if (LargeFilesGrid.SelectedItem is not LargeFileItem file) { MessageBox.Show("Сначала выберите файл в списке.", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        var answer = MessageBox.Show($"Переместить выбранный файл в Корзину?\n\n{file.Path}\nРазмер: {file.SizeText}\n\nНе удаляйте системные файлы, если не уверены в их назначении.", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);
        if (answer != MessageBoxResult.Yes) return;
        try
        {
            FileSystem.DeleteFile(file.Path, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin);
            if (LargeFilesGrid.ItemsSource is List<LargeFileItem> list) { list.Remove(file); LargeFilesGrid.Items.Refresh(); LargeFilesSummary.Text = $"Осталось в списке: {list.Count:N0}"; }
            RefreshDiskInfo();
            MessageBox.Show("Файл перемещён в Корзину, если это разрешено Windows.", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show($"Не удалось переместить файл в Корзину.\n\n{ex.Message}", "NEBULA CLEAN", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void UpdateCategoryTotals()
    {
        long total = _categories.Sum(c => c.SizeBytes);
        int files = _categories.Sum(c => c.FileCount);
        PotentialCleanupText.Text = CleanupCategory.FormatBytes(total);
        PotentialFilesText.Text = $"{files:N0} потенциальных файлов";
        CleanerTotalText.Text = $"Найдено: {CleanupCategory.FormatBytes(total)} · {files:N0} файлов";
    }

    private void SetBusy(bool busy, string status)
    {
        _busy = busy;
        BusyBar.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
        StatusText.Text = status;
        // Disable action buttons without disabling the window's visual tree/state wholesale.
        NavDashboard.IsEnabled = !busy;
        NavCleaner.IsEnabled = !busy;
        NavAnalyzer.IsEnabled = !busy;
        NavHistory.IsEnabled = !busy;
    }
}
